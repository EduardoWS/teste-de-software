package terceiro_periodo.exercicioBoliche;

public class Boliche1 {
	
	public boolean jogadas(String j) {
		if (j.length() == 21) return true;
		
		return false;
		
	}

}
